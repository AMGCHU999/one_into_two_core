# helper functions placeholder
